import java.awt.*;
import java.util.ArrayList;

/**
 * This class represents a standard building. What attributes to a building and the standard size of a building.
 * Each building that subclasses this class will have particular attributes that will reflect the above in a more
 * specified manner.
 * User: Ben
 * Date: 12/14/13
 * Time: 11:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class Building {

    // Building properties
    public int value;
    public int areaOfInfluence;
    public int tlx, tly,width, height;
    public String name;
    public boolean debug;

    private ArrayList<Integer> topWall, rightWall, bottomWall, leftWall;
    private int entranceX;
    private int entranceY;
    private int weight = 10000;

    public Building(String name, int width, int height, int tlx, int tly, int value)
    {
        this.width = width;
        this.height = height;
        this.value = value;
        this.name = name;
        this.tly = tly;
        this.tlx = tlx;
        debug = false;
        entranceX = tlx + (width) + 6;
        entranceY = tly + (height/2);
        setPerimeter();
    }

    /**
     * Draw this building onto the given graphics object.
     * @param g The graphics object to draw to.
     * @Author Ben Euden
     */
    public void draw(Graphics g, boolean debug)
    {
        g.setColor(Color.gray);
        g.fillRect(tlx, tly, width, height);
        if(debug)
        {
            //g.drawRect(tlx, tly, width, height);
            g.setColor(Color.BLACK);
            g.drawString("£" + getWeight(), tlx + width/2, tly +height /2);
        }
    }

    public int[][] getBuildingPoints()
    {
        int[][] points = new int[4][4];

        //tl, tr, bl, br
        points[0][0]= tlx;
        points[0][1]= tly;
        points[1][0]= tlx + width;
        points[1][1]= tly;
        points[2][0]= tlx;
        points[2][1]= tly + height;
        points[3][0]= tlx + width;
        points[3][1]= tly + height;

        return points;
    }

    public void setPerimeter()
    {
        int xPos = tlx -6;
        int yPos = tly -6;
        topWall= new ArrayList<Integer>();
        //Set top wall values
        for(int i = xPos; i < tlx +width+6; i++)
        {
            topWall.add(i);
        }

        // Set right wall

        rightWall = new ArrayList<Integer> ();

        for(int right = tlx +width+6; right < (tlx +width+6 + tly +height+6); right++)
        {
            rightWall.add(right);
        }

        // Set Left Wall
        leftWall = new ArrayList<Integer>();

        for(int left = tlx -6; left < getBottomLeft()-6; left++)
        {
            leftWall.add(left);
        }

        //set bottomWall
        bottomWall = new ArrayList<Integer>();

        for(int bottom = getBottomLeft()-6; bottom < (getBottomRight()+6); bottom++)
        {
            bottomWall.add(bottom);
        }
    }

    public ArrayList<Integer>[] getPerimiter()
    {
        ArrayList<Integer>[] arrays = new ArrayList[4];
        arrays[0]= topWall;
        arrays[1] = rightWall;
        arrays[2] = bottomWall;
        arrays[3] = leftWall;

        return arrays;
    }

    /**
     * @author = Adam
     */
    public void loot(){

        if(getWeight() > 0){
            int value = getValue();
            weight = weight - (10 * value);
            if(weight < 0){
                weight = 0;
            }
        }
    }

    /**
     * @author = Adam
     * @return
     */
    public boolean getEmpty(){
        boolean empty = false;
        if(getWeight() <= 0){
            empty = true;
            value = 0;
        }
        return empty;
    }

    public int getTopRight()
    {
        return tlx + width;
    }

    public int getBottomLeft()
    {
        return tly + height;
    }

    public int getBottomRight()
    {
        return ((tlx +width) + (tly +width));
    }

    public int getEntranceX(){
        return entranceX;
    }

    public int getEntranceY(){
        return entranceY;
    }

    public int getWeight(){
        return weight;
    }

    public int getValue(){
        return value;
    }
    public String getName(){
        return name;
    }

    public void riotAvoidBuilding(ArrayList<Rioter> rioters, int riotNum){
        Rioter curr = rioters.get(riotNum);

    }


}
