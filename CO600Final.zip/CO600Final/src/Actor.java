/**
 * Created with IntelliJ IDEA.
 * @author Adam & Matt
 * Date: 16/11/13
 * Time: 13:47
 *
 */

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Random;

/**
 * Superclass of Rioter, Police and Civilian
 * Author: Adam, Matt, Ben
 */

public class Actor {
    //Declare the fields
    protected int fear;
    protected int anger;
    protected int strength;
    protected int[] currLoc = new int[2];
    protected int[] targLoc = new int[2];
    protected int[] secondary = new int[2];
    protected Random rand = new Random();
    protected String type = "";
    protected int wid;
    protected int hei;
    protected boolean sideTarg = false;
    protected boolean flee = false;

    /**
     * This is the constructor, this sets up the initial location and the target locations of the actor.
     */
    public Actor(){

    }

    /**
     * @Author = Ben
     * @param g
     * @param debug
     */
    public void draw(Graphics g, Boolean debug) {
        if (debug){
            g.drawOval(getCurrx()-1, getCurry()-1, 7, 7);
            g.drawChars("T".toCharArray(),0,1,getTargx(), getTargy());
            g.drawLine(getCurrx(), getCurry(), getTargx(), getTargy());
        }
        g.fillOval(getCurrx(), getCurry(), 5, 5);
    }

    /**
     * If the actor is beyond the boundaries of the screen the actor is returned to the screen.
     * @author = Adam
     */
    public void outOfBounds(boolean currOrTarg){

        int currx = 0;
        int curry = 0;
        if(currOrTarg){
            currx = getCurrx();
            curry = getCurry();
        }
        else{
            currx = targLoc[0];
            curry = targLoc[1];
        }

        if(currx <= 6){
            currx = 10;
        }
        else if(currx >= (wid - 6)){
            currx = wid - 10;
        }

        if(curry <= 6){
            curry = 10;
        }
        else if(curry >= (hei - 6)){
            curry = hei - 10;
        }
        if(currOrTarg){
            currLoc[0] = currx;
            currLoc[1] = curry;
        }
        else{
            targLoc[0] = currx;
            targLoc[1] = curry;
        }
    }

    /**
     *
     * @param buildings
     */
    public void collBuild(ArrayList<Building> buildings){
        int curry = getCurry();
        int currx = getCurrx();
        int toTop = 0;
        int toBot = 0;
        int toLeft = 0;
        int toRight = 0;
        Random randExtra = new Random();
        Random whichWay = new Random();
        boolean upDown = whichWay.nextBoolean();
        boolean leftRight = whichWay.nextBoolean();
        int boundary = 5;

        int extrax = (6 + randExtra.nextInt(40));
        int extray = (6 + randExtra.nextInt(40));

        for(int i =0; i < buildings.size(); i++){
            Building currBuild = buildings.get(i);
            int[][] points = currBuild.getBuildingPoints();
            //collLeft
            if (points[0][0] - boundary == (currx)) {
                if (curry >= (points[0][1] - boundary) && curry <= (points[2][1] + boundary)) {
                    toTop = curry - points[0][1];
                    toBot = points[2][1] - curry;
                    if(upDown){
                        secondary(points[0][0] - extrax, points[0][1] - extray);
                    }
                    else{
                        secondary(points[2][0] - extrax, points[2][1] + extray);
                    }
                }
            }
            //collright
            else if (points[1][0] + (boundary - 1)  == (currx)) {
                if (curry  >= (points[1][1] - (boundary - 1)) && curry <= (points[3][1]) + (boundary - 1)) {
                    toTop = curry - points[1][1];
                    toBot = points[3][1] - curry;
                    if(upDown){
                        secondary(points[1][0] + extrax, points[1][1] - extray);
                    }
                    else{
                        secondary(points[3][0] + extrax, points[3][1] + extray);
                    }
                }
            }
            //collup
            else if (points[0][1] - boundary == (curry)) {
                if (currx  >= (points[0][0] - boundary) && currx <= (points[1][0]) + boundary) {
                    toLeft = currx - points[0][0];
                    toRight = points[1][0] - currx;
                    if(leftRight){
                        secondary(points[0][0] - extrax, points[0][1] -extray);
                    }
                    else{
                        secondary(points[1][0] + extrax, points[1][1] - extray);
                    }
                }
            }
            else if (points[2][1] + boundary == (curry)) {
                if (currx >= (points[2][0] - boundary) && currx <= (points[3][0]) + boundary) {
                    toLeft = currx - points[2][0];
                    toRight = points[3][0] - currx;
                    if(leftRight){
                        secondary(points[2][0] - extrax, points[2][1] + extrax);
                    }
                    else{
                        secondary(points[3][0] + extrax, points[3][1] + extray);
                    }
                }
            }
        }
    }

    /**
     *
     * @param builds
     * @param currOrTarg     - true = current
     */
    public void inBuild(ArrayList<Building> builds, boolean currOrTarg){
        for(int i = 0; i < builds.size(); i++){
            Building currBuild = builds.get(i);
            int[][] points = currBuild.getBuildingPoints();
            int newx = 0;
            int newy = 0;
            int boundary = 0;
            int currx = 0;
            int curry = 0;
            if(currOrTarg){
                boundary = 3;
                currx = getCurrx();
                curry = getCurry();
            }
            else{
                boundary = 5;
                currx = targLoc[0];
                curry = targLoc[1];
            }
            if (currx >= (points[0][0] - boundary) && currx <= (points[1][0]) + boundary){
                if (curry >= (points[0][1] - boundary) && curry <= (points[2][1]) + boundary) {

                    int left = currx - points[0][0];
                    int right = points[1][0] - currx;
                    int up = curry - points[0][1];
                    int down = points[2][1] - curry;
                    int smallerx = 0;
                    int smallery = 0;
                    boolean lr = false;
                    boolean ud = false;
                    if(left < right){
                        smallerx = left;
                        lr = true;
                    }
                    else{
                        smallerx = right;
                        lr = false;
                    }
                    if(up < down){
                        smallery = up;
                        ud = true;
                    }
                    else{
                        smallery = down;
                        ud = false;
                    }

                    //bug is between here
                    if(smallerx < smallery){
                        if(lr == true){
                            newx = (points[0][0] - 6);
                        }
                        else{
                            newx = (points[1][0] + 6);
                        }
                    }
                    else{
                        if(ud == true){
                            newy = points[0][1] - 6;
                        }
                        else{
                            newy = points[2][1] + 6;
                        }
                    }
                    if(currOrTarg){
                        if(newx != 0){
                            currLoc[0] = newx;
                        }
                        else{
                            currLoc[1] = newy;
                        }
                    }
                    else{
                        if(newx != 0){
                            targLoc[0] = newx;
                        }
                        else{
                            targLoc[1] = newy;
                        }
                    }
                    //and ends here
                }
            }
        }
    }

    public void secondary(int x, int y){
        secondary[0] = targLoc[0];
        secondary[1] = targLoc[1];
        targLoc[0] = x;
        targLoc[1] = y;
        sideTarg = true;
    }

    /**
     * @author = Adam
     * Gets the Actors current X co-ordinate
     * @return
     */

    public int getCurrx(){
        return currLoc[0];
    }

    //Gets the Actors current Y co-ordinate
    public int getCurry(){
        return currLoc[1];
    }

    //Gets the Actors target x-coordinate
    public int getTargx(){
        return targLoc[0];
    }

    //Gets the Actors target Y Co-ordinate
    public int getTargy(){
        return targLoc[1];
    }

    public void moveUp(){
        currLoc[1]--;
    }

    public void moveDown(){
        currLoc[1]++;
    }

    public void moveRight(){
        currLoc[0]++;
    }

    public void moveLeft(){
        currLoc[0]--;
    }

    public void moveTopRight(){
        currLoc[0]++;
        currLoc[1]--;
    }

    public void moveTopLeft(){
        currLoc[0]--;
        currLoc[1]--;
    }

    public void moveBotRight(){
        currLoc[0]++;
        currLoc[1]++;
    }

    public void moveBotLeft(){
        currLoc[0]--;
        currLoc[1]++;
    }

    //end author adam

    /**
     * Matt
     * @return true if they're fleeing
     * Determine the closest corner to flee to and sets target locations to that corner
     */
    public boolean flee()
    {
        int currX = getCurrx();
        int currY = getCurry();

        //If I'm in the bottom right quadrant of the map, set target location to bottom right corner
        if (currX > 700/2 && currY > 700/2) {
            targLoc[0] = 700;
            targLoc[1] = 700;
            flee = true;
        }
        //If I'm in the bottom left quadrant of the map, set target location to bottom left corner
        else if (currX > 700/2 && currY < 700/2) {
            targLoc[0] = 0;
            targLoc[1] = 700;
            flee = true;
        }
        //If I'm in the top right quadrant of the map, set target location to top right corner
        else if (currX < 700/2 && currY > 700/2) {
            targLoc[0] = 700;
            targLoc[1] = 0;
            flee = true;
        }
        //If I'm in the top left quadrant of the map, set target location to top left corner
        else if (currX < 700/2 && currY < 700/2) {
            targLoc[0] = 0;
            targLoc[1] = 0;
            flee = true;
        }
        //If I'm in the center of the map, set target location to top middle
        else if (currX == 700/2 && currY == 700/2) {
            targLoc[0] = 700/2;
            targLoc[1] = 0;
            flee = true;
        }

        return flee;
    }
}
