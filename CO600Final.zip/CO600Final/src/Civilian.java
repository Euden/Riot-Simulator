import java.util.ArrayList;

/**
 * Authors: Adam, Matt
 * Manages the civilian behaviour
 */
public class Civilian extends Actor {
    public ArrayList<Building> buildings;
    public boolean debug;
    public static int maxfear = 100;
    public boolean flee;
    public boolean fled;
    public Civilian(ArrayList<Building> buildings, int width, int height)
    {
        type = "Civilian";
        this.buildings = buildings;
        currLoc[0] = rand.nextInt(700);
        currLoc[1] = rand.nextInt(700);
        targLoc[0] = rand.nextInt(700);
        targLoc[1] = rand.nextInt(700);
        debug = false;
        flee = false;
        fear = setFear(maxfear);
        hei = height;
        wid = width;
    }

    /**
     * @author = Adam & Matt
     * @param police
     * @param rioter
     * @param civilian
     * @param buildings
     * @param i
     */
    public void move(ArrayList<Police> police, ArrayList<Rioter> rioter, ArrayList<Civilian> civilian, ArrayList<Building> buildings, int i){

        int direction = 0;
        int diffx = 0;
        int diffy = 0;
        boolean right = true;
        boolean down = true;
        boolean[] collisionArr = new boolean[9];

        //colls - whether an actor has entered the current actors radius.
        collPolice(police, civilian, i, collisionArr);
        collCivi(civilian, i, collisionArr);
        collRiot(rioter, civilian, i, collisionArr);
        int civiFear = civilian.get(i).getFear();

        //Matt
        if (civiFear > 20 && !flee) {
            flee();
            flee = true;
        }
        //End Matt

        inBuild(buildings, true);
        outOfBounds(true);
        outOfBounds(false);
                //#endChanges
        if(targLoc[0] >= currLoc[0]){
            diffx = targLoc[0] - currLoc[0];
            right = true;
        }
        else{
            diffx = currLoc[0] - targLoc[0];
            right = false;
        }
        if(targLoc[1] >= currLoc[1]){
            diffy = targLoc[1] - currLoc[1];
            down = true;
        }
        else{
            diffy = currLoc[1] - targLoc[1];
            down = false;
        }

        if (diffx ==diffy){
            if( diffx == 0 && diffy == 0 && !sideTarg){
                targLoc[0] = rand.nextInt(700);
                targLoc[1] = rand.nextInt(700);
            }
            else if( diffx == 0 && diffy == 0 && sideTarg){
                targLoc[0] = secondary[0];
                targLoc[1] = secondary[1];
                secondary[0] = 0;
                secondary[1] = 0;
                sideTarg = false;
            }
            else if(diffx == 0){
                if (down == true){
                    moveDown();
                }
                else{
                    moveUp();
                }
            }
            else if(diffy == 0){
                if (right == true){
                    moveRight();
                }
                else{
                    moveLeft();
                }
            }
            else{
                if (right == true && down == true){
                    moveBotRight();
                }
                else if(right == true && down == false){
                    moveTopRight();
                }
                else if(right == false && down == true){
                    moveBotLeft();
                }
                else{
                    moveTopLeft();
                }
            }
        }
        else if(diffx > diffy){
            if (right == true){
                moveRight();
            }
            else{
                moveLeft();
            }
        }
        else{
            if (down == true){
                moveDown();
            }
            else{
                moveUp();
            }

            if (!sideTarg) {
                collBuild(buildings);
            }
            collisionDecision(collisionArr, direction);
        }
        //Matt
        if (flee && (currLoc[0] <= 10 || currLoc[0] >= 690 || currLoc[1] <= 10 || currLoc[1] >= 690)) {
            synchronized (Simulator.civilianLock) {
                civilian.remove(i);
                fled = true;
            }
        }
    }

    public boolean getFled() { return fled; }

    /**
     * @author = Matt & Adam
     * @param police
     * @param civilian
     * @param a
     * @return
     */
    public void collPolice(ArrayList<Police> police, ArrayList<Civilian> civilian, int a, boolean[] collisionArr)
    {
        int currx = getCurrx();
        int curry = getCurry();
        int nearx = 0;
        int neary = 0;

        for (int i = 0; i < police.size(); i++)
        {
            if (i != a) {
                nearx = police.get(i).getCurrx();
                neary = police.get(i).getCurry();
                if (nearx >= (currx-6) && nearx <= (currx+6)) {
                    if (neary >= (curry-6) && neary <= (curry+6)) {
                        Actor curr = civilian.get(a);
                        Actor near = police.get(i);
                        resolveCollision(curr, near, collisionArr);
                        break;
                    }
                }
            }
        }
    }

    /**
     * authors = Adam & Matt
     * @param rioter
     * @param a
     * @return
     */
    public void collRiot(ArrayList<Rioter> rioter, ArrayList<Civilian> civilian, int a, boolean[] collisionArr)
    {
        int currx = getCurrx();
        int curry = getCurry();
        int nearx = 0;
        int neary = 0;

        for (int j = 0; j <rioter.size(); j++)
        {
            if (j != a) {
                nearx = rioter.get(j).getCurrx();
                neary = rioter.get(j).getCurry();
                if (nearx >= (currx-6) && nearx <= (currx+6)) {
                    if (neary >= (curry-6) && neary <= (curry+6)) {
                        Actor curr = civilian.get(a);
                        Actor near = rioter.get(j);
                        resolveCollision(curr, near, collisionArr);
                        break;
                    }
                }
            }
        }
    }

    /**
     * @authors = Adam & Matt
     * @param civilian
     * @param a
     * @return
     */
    public void collCivi(ArrayList<Civilian> civilian, int a, boolean[] collisionArr)
    {
        int currx = getCurrx();
        int curry = getCurry();
        int nearx = 0;
        int neary = 0;

        for (int i = 0; i < civilian.size(); i++)
        {
            if (i != a)
            {
                if (nearx >= (currx-6) && nearx <= (currx+6)) {
                    if (neary >= (curry-6) && neary <= (curry+6)) {
                        Actor curr = civilian.get(a);
                        Actor near = civilian.get(i);
                        resolveCollision(curr, near, collisionArr);
                        break;
                    }
                }
            }
        }
    }

    //this method resolves the collision, by making the actor move away from the other actor.

    /**
     * @author = Adam & Matt
     * @param curr
     * @param near
     */
    public void resolveCollision(Actor curr, Actor near, boolean[] collisionArr){

//        try {
//            PrintStream civilianTest = new PrintStream(new FileOutputStream("/Users/matthewwood/Documents/CivilianTestDoc.txt", true));
//            System.setOut(civilianTest);
//
//            civilianTest.println("Resolve collision method called");

        int currx = curr.getCurrx();
        int curry = curr.getCurry();
        int nearx = near.getCurrx();
        int neary = near.getCurry();

        if(currx == nearx){
            if(curry > neary){
                //above
                collisionArr[1] = true;
                collisionArr[2] = true;
                collisionArr[3] = true;
                //civilianTest.println("Collisions happening: top left, middle top and top right non-moveable");
            }
            else{
                //below
                collisionArr[6] = true;
                collisionArr[7] = true;
                collisionArr[8] = true;
                //civilianTest.println("Collisions happening: bottom left, middle bottom and bottom right non-moveable");
            }
        }
        else if(curry == neary){
            if(currx > nearx){
                //left
                collisionArr[1] = true;
                collisionArr[4] = true;
                collisionArr[7] = true;
                //civilianTest.println("Collisions happening: top left, middle left and bottom left non-moveable");
            }
            else{
                //right;
                collisionArr[3] = true;
                collisionArr[5] = true;
                collisionArr[8] = true;
                //civilianTest.println("Collisions happening: top middle, middle right and bottom right non-moveable");
            }
        }
        //tl bl tr br
        else if(currx < nearx){
            if(curry > neary){
                //top right
                collisionArr[2] = true;
                collisionArr[3] = true;
                collisionArr[5] = true;
                //civilianTest.println("Collisions happening: top middle, top right and middle right non-moveable");
            }
            else{
                //bottright
                collisionArr[5] = true;
                collisionArr[7] = true;
                collisionArr[8] = true;
                //civilianTest.println("Collisions happening: middle right, bottom middle and bottom right non-moveable");
            }
        }
        else if(currx > nearx){
            if(curry > neary){
                //top left
                collisionArr[2] = true;
                collisionArr[1] = true;
                collisionArr[4] = true;
                //civilianTest.println("Collisions happening: top left, middle left and top middle non-moveable");
            }
            else{
                //bottom left
                collisionArr[6] = true;
                collisionArr[7] = true;
                collisionArr[4] = true;
                //civilianTest.println("Collisions happening: bottom left, middle left and middle bottom non-moveable");
            }
        }
    }

    /**
     * Author: Adam
     * @param collisionArr
     * @param next
     */
    public void collisionDecision(boolean[] collisionArr, int next){

        if(next==0){
            next = 1;
        }
        boolean allTrue = true;
        // while the "next" field equals a move option which is not in the "collisionArr" array then pick a new number.
        for(int i = 1; i < collisionArr.length; i++){
            if( collisionArr[i] == false){
                allTrue = false;
                break;
            }
        }
        //civilianTest.println("Collisions in all directions: " + allTrue);

        if (allTrue == false){

            while (collisionArr[next] == true ){
                next = 1 + (rand.nextInt(8));
            }
            //move the actor depending on the "next" field.
            switch (next){
                case 0: break;
                case 1: moveTopLeft(); break; //;civilianTest.println("Move top left")
                case 2: moveUp(); break; //; civilianTest.println("Move top")
                case 3: moveTopRight(); break; //civilianTest.println("Move top");
                case 4: moveLeft(); break; //;; civilianTest.println("Move left")
                case 5: moveRight(); break; //;; civilianTest.println("Move right")
                case 6: moveBotLeft(); break; //;; civilianTest.println("Move bottom left")
                case 7: moveDown(); break; //;; civilianTest.println("Move down")
                case 8: moveBotRight(); break; //;; civilianTest.println("Move bottom right")
                default: break;
            }
        }
        else{
            //Don't move
            //civilianTest.println("Do not move");
        }
//            civilianTest.close();
//        } catch (FileNotFoundException e) {
//        }
    }



    public String getType() { return type; }

    public int getFear(){
        return fear;
    }

    public int setFear(int fear){
        int f = fear;
        return f;
    }

    /**
     * Author: Matt
     * @return
     */
    public boolean getFlee()
    {
        return flee;
    }

}
