import java.awt.*;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.*;

/**
 * Author: Adam, Matt
 * Manages the rioters behaviour
 */
public class Rioter extends Actor {
    //Initialise field values
    private boolean arrested = false;
    public ArrayList<Building> buildings;
    public boolean debug;
    public static int maxanger = 100;
    public static int maxstrength = 100;
    public static int maxfear = 100;
    private int group;
    private String currBName;
    Building curr;
    private boolean leader;
    public Color color = null;
    boolean flee;
    boolean fled;
    public int riotNum = 0;


    /**
     * Author: Adam
     * Initialise the fields
     * @param width = the width of the screen
     * @param height = the height of the screen
     * @param bArrList = the ArrayList containing all of the buildings within the simulator.
     * @param rioter = the Rioter ArrayList.
     * @param riotNum = the position of the current Rioter within the Rioter ArrayList.
     * @param groupNum = the number of the current group of rioters.
     * @param groupLeader = whether or not the Rioter is a groupLeader or not. If the rioter is a group leader, than they will head to new locations on their own volition, rioters
     * who are not group leaders will follow their group leader throughout the simulation.
     */
    public Rioter(int width, int height, ArrayList<Building> bArrList, ArrayList<Rioter> rioter, int riotNum, int groupNum, boolean groupLeader){

        width = width - 6;
        height = height - 6;
        //Set up their secondary targets
        secondary[0] = 0;
        secondary[1] = 0;
        type = "Rioter";
        this.buildings = bArrList;
        this.riotNum = riotNum;
        //Set anger, strength and fear
        anger = setAnger(rand.nextInt(maxanger));
        strength = setStrength(rand.nextInt(maxstrength));
        fear = setFear(rand.nextInt(maxfear));
        //Set current and target locations
        currLoc[0] = 6 + rand.nextInt(width-12);
        currLoc[1] = 6 + rand.nextInt(height-12);
        targLoc[0] = 6 + rand.nextInt(width-12);
        targLoc[1] = 6 + rand.nextInt(height-12);
        wid = width;
        hei = height;
        debug = false;
        group = groupNum;
        curr = bArrList.get(0);
        leader = groupLeader;
        flee = false;
        if (getLeader() == true)
        {
            Building comp = currentTarget();
            if (!comp.getName().equals(currBName)) {
                currBName = comp.getName();
                curr = comp;
                targLoc[0] = curr.getEntranceX() + 5;
                targLoc[1] = curr.getEntranceY();
            }
        }
        else {
            attractor(rioter, riotNum, leader);
            inBuild(buildings, false);
        }
    }

    /**
     * @return - the group number of the rioter.
     */
    public int getGroup()
    {
        return group;
    }

    /**
     * @return leader status.
     */
    public boolean getLeader()
    {
        return leader;
    }


    /**
     * Author: Adam & Matt
     * This method calls all of the methods in regards to ascertaining the next move that the rioter can make. These are recorded into a boolean array called collisionArr. If the Actor can
     * move in a direction then the field within the array will read false.
     * @param police = the ArrayList containing all of the different police actors.
     * @param rioter = the ArrayList containing all of the different rioting actors.
     * @param civilian = the ArrayList containing all of the different civilian actors.
     * @param riotNum = the rioters number within the rioter array.
     */
    public void move(ArrayList<Police> police, ArrayList<Rioter> rioter, ArrayList<Civilian> civilian, int riotNum){

        int diffx = 0;
        int diffy = 0;
        int direction = 0;
        boolean right = true;
        boolean down = true;
        Building comp = null;

        //If the rioter is not arrested
        if(!isArrested()){
            //Check building collisions and if their out of the simulation boundaries
            inBuild(buildings, true);
            if (!flee) {
                outOfBounds(true);
            }
            outOfBounds(false);

            //Get the rioters fear and anger values
            int riotFear = rioter.get(riotNum).getFear();
            int riotAnger = rioter.get(riotNum).getAnger();

            //Flee if this condition is met
            if (riotFear > 90 && riotAnger < 30 && !flee) {
                flee();
                flee = true;
            }

            //Create a new boolean array
            boolean[] collisionArr = new boolean[9];

            //Check collisions with police, other rioters and civilians
            collPolice(police, rioter, riotNum, collisionArr);
            collRiot(rioter, riotNum, collisionArr);
            collCivi(civilian, rioter, riotNum, collisionArr);

            //Movement conditions
            if(targLoc[0] >= currLoc[0]){
                diffx = targLoc[0] - currLoc[0];
                right = true;
            }
            else{
                diffx = currLoc[0] - targLoc[0];
                right = false;
            }
            if(targLoc[1] >= currLoc[1]){
                diffy = targLoc[1] - currLoc[1];
                down = true;
            }
            else{
                diffy = currLoc[1] - targLoc[1];
                down = false;
            }

            if (diffx ==diffy){
                if(diffx == 0 && diffy == 0){
                    if(sideTarg){
                        targLoc[0] = secondary[0];
                        targLoc[1] = secondary[1];
                        secondary[0] = 0;
                        secondary[1] = 0;
                        sideTarg = false;
                    }
                    else{
                    if (getLeader() == true){
                        comp = currentTarget();
                        if (!comp.getName().equals(currBName)) {
                            currBName = comp.getName();
                            curr = comp;
                            targLoc[0] = curr.getEntranceX() + 5;
                            targLoc[1] = curr.getEntranceY();
                        }
                    }
                    else {
                        attractor(rioter, riotNum, leader);
                        inBuild(buildings, false);

                    }
                }
            }
            else if(diffx == 0){
                if (down == true){
                    direction = 7;
                }
                else{
                    direction = 2;
                }
            }
            else if(diffy == 0){
                if (right == true){
                    direction = 5;
                }
                else{
                    direction = 4;
                }
            }
            else{
                if (right == true && down == true){
                    direction = 8;
                }
                else if(right == true && down == false){
                    direction = 3;
                }
                else if(right == false && down == true){
                    direction = 6;
                }
                else{
                    direction = 1;
                }
            }
        }
        else if(diffx > diffy){
            if (right == true){
                direction = 5;
            }
            else{
                direction = 4;
            }
        }
        else{
            if (down == true){
                direction = 7;
            }
            else{
                direction = 2;
            }
        }
            if(!sideTarg){
            collBuild(buildings);
            }
            collisionDecision(collisionArr, direction);
        }

        //If the rioter is fleeing and isn't arrested and their current location is within the boundaries below, remove themselves from the arraylist
        if (flee && !arrested && (currLoc[0] <= 10 || currLoc[0] >= 690 || currLoc[1] <= 10 || currLoc[1] >= 690)) {
            synchronized (Simulator.rioterLock){ //Author: Rahul
                rioter.remove(riotNum);
                fled = true;
            }
        }
    }

    public boolean getFled() { return fled; }

    /**
     * Author: Rahul
     * @return the rioters fear value
     */
    public int getFear(){
        return fear;
    }

    /**
     * Author: Rahul
     * @param fear
     * @return a manipulated fear value
     */
    public int setFear(int fear){
        int f = fear;
        return f;
    }



    /**
     * Matt
     * @return the flee boolean, true or false
     */
    public boolean getFlee()
    {
        return flee;
    }

    /**
     * Author: Matt
     * Attack the nearest police officer if the condition is met
     * @param rioter
     * @param police
     * @param a
     * @return
     */
    public boolean attack(ArrayList<Rioter> rioter, ArrayList<Police> police, int a)
    {
        boolean attack = false;

        //Get current rioter location
        int riotCurrX = rioter.get(a).getCurrx();
        int riotCurrY = rioter.get(a).getCurry();

        for (int i = 0; i < police.size(); i++)
        {
            //Get current police location
            int policeCurrX = police.get(i).getCurrx();
            int policeCurrY = police.get(i).getCurry();

            //If rioters strength and anger are both above a certain level
            if (maxstrength > 70 && anger > 80) {
                //Find the nearest police officer
                if (policeCurrX >= (riotCurrX-20) && policeCurrX <= (riotCurrX+20)) {
                    if (policeCurrY >= (riotCurrY-20) && policeCurrY <= (riotCurrY+20)) {
                        //Set my target location as that police officers current locations
                        targLoc[0] = policeCurrX;
                        targLoc[1] = policeCurrY;
                        maxstrength--;
                        attack = true;
                    }
                }
            }
        }

        return attack;
    }

    public int getRiotNum(){
        return riotNum;
    }

    /**
     * Uses a formula to establish which building the Rioter will loot next.
     * @Author = Adam
     * @return - the building which is the new target
     */
    public Building currentTarget(){
        double nextDist = 0;
        double currDist = 0;
        double currScore = 0;
        double nextScore = 0;
        Building next = null;
        Building curr = null;
        for(int i = 0; i< buildings.size(); i++){
            if(!buildings.get(i).getEmpty()){
                if(buildings.get(i).getValue() > 0){
                    curr = buildings.get(i);
                    currDist = estDistance(curr);
                    currScore = estScore(curr, currDist);
                    break;
                }
            }

        }
        for( int i = 1; i < buildings.size(); i++){
            if(!buildings.get(i).getEmpty()){
                if(buildings.get(i).getValue() > 0){
                next = buildings.get(i);
                    //INSERT FOLRMULAE HERE COMPARE IF NEXT GREATER THAN CURR THEN CURR ==NEXT. TARGLOC = entrance
                    // 1000 - dist * value.
                    // make targ destination have a name
                    nextDist = estDistance(next);
                    nextScore = estScore(next, nextDist);
                    if(nextScore >= currScore){
                        curr = next;
                        currDist = nextDist;
                        currScore = nextScore;
                    }
                }
            }
        }

        if(currDist <= 5){
            try{
                curr.loot();
            }
            catch(NullPointerException e){
                JOptionPane.showMessageDialog(null, "All the buildings have been looted", "Simulation End", JOptionPane.PLAIN_MESSAGE);
                System.out.println("All buildings have been completely looted.");
                System.exit(0);
            }
        }
        return curr;
    }

    /**
     * Establishes the distance between the rioter and the buildings entrance.
     * @Author = Adam
     * @param curr - the current building
     * @return the distance
     */
    public double estDistance(Building curr){
        double distance = 0.0;
        int distx = curr.getEntranceX() + 5;
        int disty = curr.getEntranceY();
        int cx = getCurrx();
        int cy = getCurry();
        if (distx > cx){
            distx = distx - cx;
        }
        else{
            distx = cx - distx;
        }
        if (disty > cy){
            disty = disty - cy;
        }
        else{
            disty = cy - disty;
        }

        int distx2 = distx * distx;
        int disty2 = disty * disty;
        int distt = distx2+disty2;

        distance = Math.sqrt((distt));
        return distance;
    }

    /**
     * @Author = Adam
     * @param curr - the current building
     * @param distance - the distance between the rioter and the current building.
     * @return the score
     */
    public double estScore (Building curr, double distance){
        int weight = curr.getWeight();
        int value = curr.getValue();
        double score = (weight- distance);
        if(score < 0){
            score = 0;
        }
        score = score * value;
        return score;
    }

    /**
     * Author: Adam & Matt
     * Check to see if they rioter will collide with any police
     * @param police - array of police
     * @param rioter - array of rioters
     * @param riotNum - the current Rioter field within the array.
     * @param collisionArr - - array containing all the directions which the actor will collide with another actor.
     * Assumption that only one Actor within radius of another Actor
     * The code checks the other actors to see if any other actors are nearby, if there is anyone they will attempt to avoid them.
     */
    public void collPolice(ArrayList<Police> police, ArrayList<Rioter> rioter, int riotNum, boolean[] collisionArr)
    {
        int currx = getCurrx();
        int curry = getCurry();
        int nearx = 0;
        int neary = 0;

        for (int i = 0; i < police.size(); i++)
        {
            //Get the police locations
            nearx = police.get(i).getCurrx();
            neary = police.get(i).getCurry();
            //If there is a police officer within this radius, call collision method
            if (nearx >= (currx-6) && nearx <= (currx+6)) {
                if (neary >= (curry-6) && neary <= (curry+6)) {
                    Actor curr = rioter.get(riotNum);
                    Actor near = police.get(i);

                    resolveCollision(curr, near, collisionArr);
                }
            }
        }
    }

    /**
     * Author: Adam & Matt
     * @param rioter array of rioters
     * @param riotNum - the current rioters field within the array.
     * @param collisionArr - - array containing all the directions which the actor will collide with another actor.
     * Check for other rioters near to them
     */
    public void collRiot(ArrayList<Rioter> rioter, int riotNum, boolean[] collisionArr)
    {
        int currx = getCurrx();
        int curry = getCurry();
        int nearx = 0;
        int neary = 0;

        for (int j = 0; j <rioter.size(); j++)
        {
            //If the rioter nearby is not arrested
            if (j != riotNum && rioter.get(j).isArrested() == false) {
                //Get the nearby rioter location
                nearx = rioter.get(j).getCurrx();
                neary = rioter.get(j).getCurry();
                //Check to see how close they are and call collision method if too close
                if (nearx >= (currx-6) && nearx <= (currx+6)) {
                    if (neary >= (curry-6) && neary <= (curry+6)) {
                        Actor curr = rioter.get(riotNum);
                        Actor near = rioter.get(j);

                        resolveCollision(curr, near, collisionArr);
                    }
                }
            }
        }
    }

    /**
     * Author: Matt & Adam
     * @param civilian - array of civilians
     * @param rioter - array of rioters
     * @param riotNum - references the field of the rioter within the rioter arraylist.
     * @param collisionArr - an array which details which directions the actor will collide with another actor.
     * @return
     * Check to see if there are any civilians nearby
     */
    public void collCivi(ArrayList<Civilian> civilian, ArrayList<Rioter> rioter, int riotNum, boolean[] collisionArr)
    {
        int currx = getCurrx();
        int curry = getCurry();
        int nearx = 0;
        int neary = 0;

        for (int j = 0; j <civilian.size(); j++)
        {
            if (j != riotNum) {
                //Get the civilian locations
                nearx = civilian.get(j).getCurrx();
                neary = civilian.get(j).getCurry();
                //If they're within this radius of me, call collision method
                if (nearx >= (currx-6) && nearx <= (currx+6)) {
                    if (neary >= (curry-6) && neary <= (curry+6)) {
                        Actor curr = rioter.get(riotNum);
                        Actor near = civilian.get(j);

                        resolveCollision(curr, near, collisionArr);
                    }
                }
            }
        }
    }

    /**
     * Author: Adam & Matt
     * Fills the collision array with "TRUE" where the rioter cannot move.
     * so if the Rioter cannot move up, it will make top left, up and top right references = true.
     * @param curr - current actor
     * @param near - actor which the current actor is to collide with.
     * @param collisionArr - array containing all the directions that the actor will collide with another actor.
     */
    public void resolveCollision(Actor curr, Actor near, boolean[] collisionArr){

        int currx = curr.getCurrx();
        int curry = curr.getCurry();
        int nearx = near.getCurrx();
        int neary = near.getCurry();

        if(currx == nearx){
            if(curry > neary){
                //above
                collisionArr[1] = true;
                collisionArr[2] = true;
                collisionArr[3] = true;
            }
            else{
                //below
                collisionArr[6] = true;
                collisionArr[7] = true;
                collisionArr[8] = true;
            }
        }
        else if(curry == neary){
            if(currx > nearx){
                //left
                collisionArr[1] = true;
                collisionArr[4] = true;
                collisionArr[7] = true;
            }
            else{
                //right;
                collisionArr[2] = true;
                collisionArr[5] = true;
                collisionArr[8] = true;
            }
        }
        //tl bl tr br
        else if(currx < nearx){
            if(curry > neary){
                //top right
                collisionArr[2] = true;
                collisionArr[3] = true;
                collisionArr[5] = true;
            }
            else{
                //bottright
                collisionArr[5] = true;
                collisionArr[7] = true;
                collisionArr[8] = true;
            }
        }
        else if(currx > nearx){
            if(curry > neary){
                //top left
                collisionArr[2] = true;
                collisionArr[1] = true;
                collisionArr[4] = true;
            }
            else{
                //bottom left
                collisionArr[6] = true;
                collisionArr[7] = true;
                collisionArr[4] = true;
            }
        }

    }

    /**
     * Compares the direction that the Rioter would like to travel against the collision away. If this direction is equal to false then it will move in that direction. If it
     * equals true then it will randomly select a direction that they are able to move into without a collision.
     * Author: Adam
     * @param collisionArr - array containing all the directions that the actor will collide with another actor.
     * @param nextDirection - The direction the actor would like to travel in.
     */
    public void collisionDecision(boolean[] collisionArr, int nextDirection){

        if(nextDirection==0){
            nextDirection = 1;
        }
        boolean allTrue = true;
        // while the "next" field equals a move option which is not in the "collisionArr" array then pick a new number.
        for(int i = 1; i < collisionArr.length; i++){

            if( collisionArr[i] == false){
                allTrue = false;
                break;
            }
        }

        if (allTrue == false){

            while (collisionArr[nextDirection] == true ){
                nextDirection = 1 + (rand.nextInt(8));
            }
            //move the actor depending on the "next" field.
            switch (nextDirection){
                case 0: break;
                case 1: moveTopLeft(); break;
                case 2: moveUp(); break;
                case 3: moveTopRight(); break;
                case 4: moveLeft(); break;
                case 5: moveRight(); break;
                case 6: moveBotLeft(); break;
                case 7: moveDown(); break;
                case 8: moveBotRight(); break;
                default: break;
            }
        }
        else{

            //DONT MOVE
        }
    }

    public String getType()
    {
        return type;
    }

    /**
     * Has the rioter been arrested?
     * Author: Adam
     * @return
     */
    public boolean isArrested()
    {
        return arrested;
    }

    /**
     * If current strength is above that of the arresting officer, resist and run.
     * Strength will slowly decrease every time an officer tries to arrest.
     * @Author Ben
     *
     * @Param ar Arresting Officer.
     */
    public void resistArrest(Police ar)
    {
        if (anger > 40 || fear > 40) {
            if(strength > ar.getStrength()) {
                strength -= 5;
            }
            else{
                arrest();
            }
        }
        else {
            arrest();
        }
    }

    /**
     * Set the arrest boolean to true.
     * Author: Adam
     */
    public void arrest()
    {
        arrested = true;
    }

    /**
     * Gets the direction that each actor is facing
     * @param rioters
     * @param a
     * @return
     * Author: Matt
     */
    public int direction(ArrayList<Rioter> rioters, int a)
    {
        //System.out.println("direction");
        int direction = 0;

        int currX = rioters.get(a).getCurrx();
        int currY = rioters.get(a).getCurry();
        int targX = rioters.get(a).getTargx();
        int targY = rioters.get(a).getTargy();

        //Current actor is facing left
        if (targX < currX && targY == currY) {
            direction = 1;
            return direction;
        }
        //Current actor is facing right
        if (targX > currX && targY == currY) {
            direction = 2;
            return direction;
        }
        //Current actor is facing down
        if (targY > currY && targX == currX) {
            direction = 3;
            return direction;
        }
        //Current actor facing up
        if (targY < currY && targX == currX) {
            direction = 4;
            return direction;
        }
        //Current actor facing top left
        if (targX < currX && targY < currY) {
            direction = 5;
            return direction;
        }
        //Current actor facing top right
        if (targX > currX && targY < currY) {
            direction = 6;
            return direction;
        }
        //Current actor facing bottom left
        if (targX < currX && targY > currY) {
            direction = 7;
            return direction;
        }
        //Current actor facing bottom right
        if (targX > currX && targY > currY) {
            direction = 8;
            return direction;
        }
        return direction;
    }

    /**
     * Detect everything within a 180 degree field of view
     * Intended for line of sight
     * Not implemented
     * Author: Matt
     */
    public boolean detection(ArrayList<Rioter> rioters, int a, ArrayList<Police> police)
    {
        boolean detection = false;
        int currX = rioters.get(a).getCurrx();
        int currY = rioters.get(a).getCurry();
        //Get the direction of current actor
        //For every rioter
        for (int i = 0; i < rioters.size(); i++)
        {
            int direction = direction(rioters, a);
            //And that actor isn't the current actor
            if (i != a) {
            int nearX = rioters.get(i).getCurrx();
            int nearY = rioters.get(i).getCurry();

            //If actor facing left, set radius of 180 degrees
                if (direction == 1)
                {
                    if (nearX >= (currX-30) && nearY >= (currY-30) && nearY <= (currY+30))
                        {
                            detection = true;
                            Actor curr = rioters.get(a);
                            Actor near = rioters.get(i);
                            //flock(curr, near, rioters, police);
                            return detection;
                        }
                    }
                    //If actor facing right, set radius of 180 degrees
                if (direction == 2)
                {
                    if (nearX <= (currX+30) && nearY >= (currY-30) && nearY <= (currY+30))
                    {
                         detection = true;
                         Actor curr = rioters.get(a);
                         Actor near = rioters.get(i);
                        // flock(curr, near, rioters, police);
                         return detection;
                    }
                }
                //If actor facing down, set radius of 180 degrees
                if (direction == 3)
                {
                    if (nearX <= (currX+30) && nearX <= (currX+30) && nearY <= (currY+30))
                    {
                        detection = true;
                        Actor curr = rioters.get(a);
                        Actor near = rioters.get(i);
                        //flock(curr, near, rioters, police);
                        return detection;
                    }
                }
                //If actor facing up, set radius of 180 degrees
                if (direction == 4)
                {
                    if (nearX >= (currX-30) && nearX <= (currX+30) && nearY <= (currY+30))
                    {
                        detection = true;
                        Actor curr = rioters.get(a);
                        Actor near = rioters.get(i);
                        //flock(curr, near, rioters, police);
                        return detection;
                    }
                }
                //If actor facing top left, set radius of 180 degrees
                if (direction == 5)
                {
                    if ((nearX <= (currX+30) && nearY >= (currY-30)) && (nearX >= (currX-30) && nearY >= (currX-30)) && (nearX >= (currX-30) && nearY <= (currY+30)))
                    {
                        detection = true;
                        Actor curr = rioters.get(a);
                        Actor near = rioters.get(i);
                        //flock(curr, near, rioters, police);
                        return detection;
                    }
                }
                //If actor facing top right, set radius of 180 degrees
                if (direction == 6)
                {
                    if ((nearX >= (currX-30) && nearY >= (currX-30)) && (nearX <= (currX+30) && nearY >= (currY-30)) && (nearX <= (currX+30) && nearY <= (currY+30)))
                    {
                        detection = true;
                        Actor curr = rioters.get(a);
                        Actor near = rioters.get(i);
                        //flock(curr, near, rioters, police);
                        return detection;
                    }
                }
                //If actor facing bottom left, set radius of 180 degrees
                if (direction == 7)
                {
                    if ((nearX <= (currX+30) && nearY <= (currY+30)) && (nearX >= (currX-30) && nearY <= (currY+30)) && (nearX >= (currX-30) && nearY >= (currX-30)))
                    {
                        detection = true;
                        Actor curr = rioters.get(a);
                        Actor near = rioters.get(i);
                        return detection;
                    }
                }
                //If actor facing bottom right, set radius of 180 degrees
                if (direction == 8)
                    {
                    if ((nearX <= (currX+30) && nearY >= (currY-30)) && (nearX <= (currX+30) && nearY <= (currY+30)) && (nearX >= (currX-30) && nearY <= (currY+30)))
                    {
                        detection = true;
                        Actor curr = rioters.get(a);
                        Actor near = rioters.get(i);
                        return detection;
                    }
                }
            }
        }
        return detection;
    }

    /**
     * The Rioters target location becomes the Group Leaders current location (with a random variable included in an attempt to stop clustering)
     * Author: Adam
     * @param rioter
     * @param a
     * @param leader
     */

    public void attractor(ArrayList<Rioter> rioter, int a, boolean leader)
    {
        Random randcor = new Random();
        for (int i = 0; i < rioter.size(); i++)
        {
            if (rioter.get(a).getGroup() == rioter.get(i).getGroup()) {
                if (rioter.get(i).getLeader() == true) {
                    int targx = rioter.get(i).getCurrx();
                    int targy = rioter.get(i).getCurry();
                    targLoc[0] = (randcor.nextInt(10) - 5) + targx;
                    targLoc[1] = (randcor.nextInt(10) - 5) + targy;
                }
            }
        }
    }

    //set target location to that actor +/- 10


    /**
     * Author: Rahul
     * @return
     */
    public int getAnger()
    {
        return anger;
    }

    /**
     * Author: Rahul
     * @return
     */
    public Color getColor(){

        return color;

    }

    /**
     * Author: Rahul
     * @param c - Takes in color of rioter and returns a new one
     */
    public void setColor(Color c){
        color = c;
    }

    /**
     * Author: Rahul
     * @param s - Takes in strength value of rioter to change
     * @return -Returns new strength value of rioter
     */
    public int setStrength(int s) {
        strength = s;
        return strength;
    }

    /**
     * Author: Rahul
     * @return - returns strength value of rioter
     */
    public int getStrength(){ return strength; }

    /**
     * Author: Rahul
     * @param anger - Takes in anger value of rioter
     * @return - Returns new value
     */
    public int setAnger(int anger)
    {
        int a = anger;
        return a;
    }
}


