import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.Random;

public class Simulator extends JPanel {

    private boolean running;
    private int FPS = 30;
    private long targetTime = 1000/FPS;
    public boolean debug;
    public ArrayList<Police> police = new ArrayList<Police>();
    public ArrayList<Rioter> rioter = new ArrayList<Rioter>();
    public ArrayList<Civilian> civilians = new ArrayList<Civilian>();
    public ArrayList<Building> buildings = new ArrayList<Building>();
    public static JLabel titleLabel;
    public static JCheckBox debugCheck;
    public static final Object rioterLock = new Object(); // Author: Rahul
    public static final Object policeLock = new Object(); // Author: Rahul
    public static final Object civilianLock = new Object(); // Author: Matt
    public static final int WIDTH = 700;
    public static final int HEIGHT = 700;
    public static JFrame screenFrame = new JFrame("Simulation");
    final Building londis = new Building("Londis", 100, 100, 50, 500, 10);
    final Building bank = new Building("Bank", 50, 100, 200, 500, 10);
    final Building bar = new Building("Bar", 50, 100, 300, 500, 10);
    final Building bo = new Building("Bo's Cars", 50, 100, 500, 500, 10);
    final Building Museum = new Building("Bank", 50, 100, 600, 500, 1);
    final Building tesco = new Building("Tesco", 150, 100, 500, 350, 10);
    final Building street = new Building("kings street housing", 300, 100, 50, 350, 0);
    final Building nickle = new Building("Nickle Court Housing", 150, 150, 500, 50, 10);
    final Building sburys = new Building("Sainsburys", 50, 50, 50, 50, 10);
    final Building poundShop = new Building("pond shop", 50, 50, 50, 150, 10);
    final Building kbar = new Building("K Bar", 150, 50, 150, 50, 10);
    final Building lol = new Building("Lol", 150, 50, 150, 150, 10);
    public Random randTarg = new Random();
    public int riotTarget = 0;
    public int groupNum = 0;
    boolean groupLeader = false;
    public int riotNum = 0;
    public int policePerGroup = 8;
    public int riotersPerGroup = 8;
    public Random randomx = new Random(WIDTH);
    public Random randomy = new Random(HEIGHT);

    public Simulator()
    {

    }

    /**
     * Author: Rahul
     * @param numRiot - number of rioters
     * @param numPol - number of police
     * @param numCiv - number of civilians
     */
    public void sim (int numRiot, int numPol, int numCiv) {

        //Add the buildings to the arrayList
        buildings.add(bo);
        buildings.add(bank);
        buildings.add(bar);
        buildings.add(londis);
        buildings.add(poundShop);
        buildings.add(street);
        buildings.add(tesco);
        buildings.add(nickle);
        buildings.add(Museum);
        buildings.add(kbar);
        buildings.add(lol);
        buildings.add(sburys);

        //Add the rioters to the arrayList
        for (int i = 0; i < numRiot; i++){
            if (i % riotersPerGroup == 0) {
                groupNum++;
                rioter.add(new Rioter(WIDTH, HEIGHT, buildings, rioter, riotNum, groupNum, true));
            }
            else {
                rioter.add(new Rioter(WIDTH, HEIGHT, buildings, rioter, riotNum, groupNum, false));
                riotNum++;
            }
        }

        //Add police to the arrayList
        for (int i = 0; i < numPol; i++){
            if (i % policePerGroup == 0) {
                riotTarget = randTarg.nextInt(numRiot);
            }
            police.add(new Police(rioter, WIDTH, HEIGHT, riotTarget, buildings));
        }

        //Add civilians to the arrayList
        for (int i = 0; i < numCiv; i++){
            civilians.add(new Civilian(buildings, WIDTH, HEIGHT));
        }

        //Set size of screenFrame
        //Initialise all the GUI elements
        screenFrame.setMaximumSize(new Dimension(WIDTH, HEIGHT));

        JPanel pane = (JPanel)screenFrame.getContentPane();
        pane.setBorder(new EmptyBorder(6,6,6,6));
        pane.setLayout(new BorderLayout(6,6));

        titleLabel = new JLabel("Riot Simulation");
        titleLabel.setVerticalTextPosition(AbstractButton.CENTER);
        titleLabel.setHorizontalTextPosition(AbstractButton.CENTER);

        JPanel rightPane = new JPanel(new GridLayout(0,1));
        JPanel leftPane = new JPanel(new GridLayout(0,1));

        JPanel a = new JPanel();
        a.setBorder(new EtchedBorder());

        pane.add(a, BorderLayout.CENTER);

        pane.add(titleLabel, BorderLayout.NORTH);

        //Debug section. Added by Ben
        JPanel debugSection = new JPanel();
        JLabel debugLabel = new JLabel("DEBUG");
        debugCheck = new JCheckBox("Debug");
        final Screen gui = new Screen(police, rioter, buildings, civilians);
        debugCheck.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gui.debug = !gui.debug;
            }
        });
        debugSection.setLayout(new GridLayout(0,1));
        debugSection.add(debugCheck);
        debugSection.setBorder(new EtchedBorder());
        //End author: Ben

        //Start author: Rahul
        rightPane.add(debugSection, BorderLayout.CENTER);

        pane.add(rightPane, BorderLayout.EAST);
        pane.add(leftPane, BorderLayout.WEST);
        pane.add(a, BorderLayout.CENTER);
        JMenuBar menuBar = new JMenuBar();
        JMenu options = new JMenu("Options");
        JMenuItem about = new JMenuItem("About");
        JMenuItem exit = new JMenuItem("Exit");
        menuBar.add(options);
        options.add(about);
        options.add(exit);

        //Author: Rebecca
        about.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane optionPane = new JOptionPane(new JLabel("-Crowd Based Simulation with Artificial Intelligence- -Riot Simulation- -Adam Murgatroyd, Rahul Govind, Matt Wood, Ben Euden, Becca Tancred- -Peter Kenny-",JLabel.CENTER));
                JDialog dialog = optionPane.createDialog("");
                dialog.setModal(true);
                dialog.setVisible(true);
            }
        });

        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        //End Author: Rebecca

        //Author: Rahul
        final JLabel avgAnger = new JLabel("Average Anger: " );
        final JLabel avgFear = new JLabel("Average Fear: "); //Added by Matt
        final JLabel arrested = new JLabel("Total Arrested: ");
        final JLabel cFled = new JLabel("Civilian Total Fleeing: "); //Added by Matt
        final JLabel rFled = new JLabel("Rioter Total Fleeing: "); //Added by Matt

        rightPane.add(avgAnger);
        rightPane.add(avgFear);
        rightPane.add(arrested);
        rightPane.add(cFled);
        rightPane.add(rFled);

        gui.addPropertyChangeListener("GUI", new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                avgAnger.setText("Average Anger: " + gui.currentAnger);
                avgFear.setText("Average Fear: " + gui.currentFear);
                arrested.setText("Total Arrested: " + gui.totalArrested);
                cFled.setText("Civilian Total Fleeing: " + gui.civiTotalFleeing);
                rFled.setText("Rioter Total Fleeing: " + gui.riotTotalFleeing);
            }
        }
        );

        screenFrame.setJMenuBar(menuBar);
        screenFrame.setLocationRelativeTo(null);
        screenFrame.setLocation(0, 0);
        screenFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        pane.add(gui, BorderLayout.CENTER);

        screenFrame.setSize(new Dimension(2048, 1480));
        screenFrame.pack();
        screenFrame.requestFocus();
        screenFrame.setVisible(true);
        //Author: Rebecca

        //Author: Rebecca
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                Simulator.screenFrame.pack();
                gui.run();
            }
        });
        //End Author: Rebecca
    }
}