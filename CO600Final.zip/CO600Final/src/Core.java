import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;
import org.omg.DynamicAny._DynSequenceStub;
import org.omg.PortableServer._ServantActivatorStub;

import java.awt.event.*;
import java.lang.reflect.Array;
import java.text.NumberFormat;
import java.text.spi.NumberFormatProvider;
import java.util.ArrayList;
import java.lang.Object.*;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import javax.swing.text.DocumentFilter.FilterBypass;


/**
 * Author: Rebecca
 * Initialise and show the starting GUI
 */
public class Core {

    public static JLabel rioterLabel;
    public static JLabel policeLabel;
    public static JLabel titleLabel;
    public static JLabel civilianLabel;
    public static JButton startButton;
    public static int numRiot = 0;
    public static int numPol = 0;
    public static int numCiv = 0;
    public static int[] riotNumbers = new int[1000];
    public static int[] polNumbers = new int[1000];
    public static int[] civNumbers = new int[1000];
    static JComboBox listR = new JComboBox();
    static JComboBox listP = new JComboBox();
    static JComboBox listC = new JComboBox();
    public static Container riotPane = new Container();
    public static Container polPane = new Container();
    public static Container civPane = new Container();


    /**
     * Author: Rebecca
     * Initialise the GUI
     * @param args
     */
    public static void main(String[] args)
    {

        final JFrame frame = new JFrame("Riot Sim");

        rioterLabel = new JLabel("Number of Rioters: ");
        rioterLabel.setSize(new Dimension(150, 10));
        rioterLabel.setVerticalTextPosition(AbstractButton.CENTER);
        rioterLabel.setHorizontalTextPosition(AbstractButton.CENTER);

        policeLabel = new JLabel("Number of Police Officers: ");
        policeLabel.setSize(new Dimension(170, 10));
        policeLabel.setVerticalTextPosition(AbstractButton.CENTER);
        policeLabel.setHorizontalTextPosition(AbstractButton.CENTER);

        civilianLabel = new JLabel("Number of Civilians: ");
        civilianLabel.setSize(new Dimension(150, 10));
        civilianLabel.setVerticalTextPosition(AbstractButton.CENTER);
        civilianLabel.setHorizontalTextPosition(AbstractButton.CENTER);

        titleLabel = new JLabel("Riot Simulation!");
        titleLabel.setSize(new Dimension(150, 10));
        titleLabel.setVerticalTextPosition(AbstractButton.CENTER);
        titleLabel.setHorizontalTextPosition(AbstractButton.CENTER);

        startButton = new JButton("Start");
        startButton.setVerticalTextPosition(AbstractButton.CENTER);
        startButton.setHorizontalTextPosition(AbstractButton.CENTER);
        startButton.setSize(new Dimension(140, 10));

        addComponentsToPane(frame.getContentPane());
        frame.setMaximumSize(new Dimension(1024, 768));
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.setLocation(0, 0);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();

        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                numRiot = (Integer) listR.getSelectedItem();
                numPol = (Integer) listP.getSelectedItem();
                numCiv = (Integer) listC.getSelectedItem();
                frame.dispose();
                Simulator simTest = new Simulator();
                simTest.sim(numRiot, numPol, numCiv);
            }
        });
    }

    /**
     * Author: Rebecca
     * Add all the components to the GUI
     * @param pane
     */
    public static void addComponentsToPane(Container pane) {
        for (int i = 0; i<riotNumbers.length;i++){
            riotNumbers[i] = i+1;
        }

        for (int i = 0; i<polNumbers.length;i++){
            polNumbers[i] = i+1;
        }

        for (int i = 0; i<civNumbers.length;i++){
            civNumbers[i] = i+1;
        }

        pane.setLayout(new BoxLayout(pane, BoxLayout.Y_AXIS));
        pane.setSize(1024, 768);
        pane.add(titleLabel);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        riotPane.setLayout(new GridLayout(2, 1));
        riotPane.add(rioterLabel);
        addRioterComboBox(riotNumbers, riotPane);

        pane.add(riotPane);
        pane.add(new JSeparator(SwingConstants.HORIZONTAL));

        polPane.setLayout(new GridLayout(2, 1));
        polPane.add(policeLabel);
        addPoliceComboBox(polNumbers, polPane);

        pane.add(polPane);
        pane.add(new JSeparator(SwingConstants.HORIZONTAL));

        civPane.setLayout(new GridLayout(2, 1));
        civPane.add(civilianLabel);
        addCivilianComboBox(civNumbers, civPane);

        pane.add(civPane);
        pane.add(new JSeparator(SwingConstants.HORIZONTAL));

        pane.add(startButton);
        startButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        pane.revalidate();
    }

    /**
     * Author: Rebecca
     * Initialise rioter combobox
     * @param text
     * @param container
     */
    private static void addRioterComboBox(int[] text, Container container)
    {
        for (int i = 1; i <= text.length; i++)
        {
            listR.addItem(i);
        }
        listR.setAlignmentX(Component.CENTER_ALIGNMENT);
        container.add(listR);
        listR.setSize(new Dimension(100, 10));

    }

    /**
     * Author: Rebecca
     * Initialise police combobox
     * @param text
     * @param container
     */
    private static void addPoliceComboBox(int[] text, Container container)
    {
        for (int i = 1; i <= text.length; i++)
        {
            listP.addItem(i);
        }
        listP.setAlignmentX(Component.CENTER_ALIGNMENT);
        container.add(listP);
        listP.setSize(new Dimension(100, 10));

    }

    /**
     * Author: Rebecca
     * Initialise civilian combobox
     * @param text
     * @param container
     */
    private static void addCivilianComboBox(int[] text, Container container)
    {
        for (int i = 1; i <= text.length; i++)
        {
            listC.addItem(i);
        }
        listC.setAlignmentX(Component.CENTER_ALIGNMENT);
        container.add(listC);
        listC.setSize(new Dimension(100, 10));
    }

}