import java.util.ArrayList;

/**
 * Author: Adam, Matt, Ben
 * Manage the behaviour of the police class
 */

public class Police extends Actor {

    //Declare the fields
    private int currentRioter = 0;
    public ArrayList<Building> buildings;
    public int[] secondary = new int[2];
    public int strength;
    boolean flee;
    boolean fled;
    boolean attack;
    private int maxHealth = 100;
    public static int maxstrength = 100;

    public Police(ArrayList<Rioter> rioter, int width, int height, int target, ArrayList<Building> buildings){
        //Initialise the variables
        type = "Police";
        strength = rand.nextInt(maxstrength);
        secondary[0] = 0;
        secondary[1] = 0;
        currLoc[0] = rand.nextInt(width);
        currLoc[1] = rand.nextInt(height);
        this.buildings = buildings;
        wid = width;
        hei = height;
        currentRioter = target;
        inBuild(buildings, false);
        updateTargetRioter(rioter.get(target));
    }

    /**
     * Updates the target location to the next rioter who is neither arrested not fled.
     * Author: Adam
     * @param rioter
     */
    public void updateTargetRioter(Rioter rioter){
        targLoc[0] = rioter.getCurrx();
        targLoc[1] = rioter.getCurry();
    }

    /**
     * Author: Adam & Matt
     * @param police - the ArrayList containing all of the different police actors.
     * @param rioter - the ArrayList containing all of the different rioting actors.
     * @param civilian - the ArrayList containing all of the different civilian actors.
     * @param policeNum - references the field within the police ArrayList which relates to this Police object.
     * Move the police
     */
    public void move(ArrayList<Police> police, ArrayList<Rioter> rioter, ArrayList<Civilian> civilian, int policeNum){

        int direction = 0;
        int diffx = 0;
        int diffy = 0;
        boolean right = true;
        boolean down = true;
        if(!sideTarg){
            synchronized (Simulator.policeLock){
                if (currentRioter >= rioter.size()) {
                    return;
                }
                if (rioter.get(currentRioter).isArrested()){
                    currentRioter++;
                    if (currentRioter >= rioter.size()) {
                        currentRioter = 0;
                    }
                    updateTargetRioter(rioter.get(currentRioter));
                }
                else{
                    updateTargetRioter(rioter.get(currentRioter));
                }
            }
        }
        boolean[] collisionArr = new boolean[9];
        inBuild(buildings, true);
        outOfBounds(true);
        outOfBounds(false);
        collPolice(police, policeNum, collisionArr);
        collCivi(civilian, police, policeNum, collisionArr);

        if (maxHealth == 0)
        {
            //Do nothing
        }

        for (int i = 0; i < police.size(); i++) {
            if (maxHealth < 15)
            {
                flee();
                flee = true;
            }
        }



        //#endChanges
        if(targLoc[0] >= currLoc[0]){
            diffx = targLoc[0] - currLoc[0];
            right = true;
        }
        else{
            diffx = currLoc[0] - targLoc[0];
            right = false;
        }
        if(targLoc[1] >= currLoc[1]){
            diffy = targLoc[1] - currLoc[1];
            down = true;
        }
        else{
            diffy = currLoc[1] - targLoc[1];
            down = false;
        }

        if (diffx == diffy){
            if(diffx <= 5 && diffy <= 5 && !sideTarg){
                //ARREST THE RIOTER
                rioter.get(currentRioter).resistArrest(this);;

                currentRioter++;
                if (currentRioter >= rioter.size()) {
                    currentRioter = 0;
                }
                updateTargetRioter(rioter.get(currentRioter));
            }
            if(diffx == 0 && diffy == 0 && sideTarg){
                targLoc[0] = secondary[0];
                targLoc[1] = secondary[1];
                secondary[0] = 0;
                secondary[1] = 0;
                sideTarg = false;

            }
            else if(diffx == 0){
                if (down == true){
                    direction = 7;
                }
                else{
                    direction = 2;
                }
            }
            else if(diffy == 0){
                if (right == true){
                    direction = 5;
                }
                else{
                    direction = 4;
                }
            }
            else{
                if (right == true && down == true){
                    direction = 8;
                }
                else if(right == true && down == false){
                    direction = 3;
                }
                else if(right == false && down == true){
                    direction = 6;
                }
                else{
                    direction = 1;
                }
            }
        }
        else if(diffx > diffy){
            if (right == true){
                direction = 5;
            }
            else{
                direction = 4;
            }
        }
        else{
            if (down == true){
                direction = 7;
            }
            else{
                direction = 2;
            }
        }
        if(!sideTarg){
            collBuild(buildings);
        }

        collisionDecision(collisionArr, direction);
        if (flee && (currLoc[0] <= 10 || currLoc[0] >= 690 || currLoc[1] <= 10 || currLoc[1] >= 690)) {
            synchronized (Simulator.policeLock) {
                police.remove(policeNum);
                fled = true;
            }
        }
    }

    public boolean getFled() { return fled; }

    public int getHealth() { return maxHealth; }

    public int setHealth(int health) {
        maxHealth = health;
        return maxHealth;
    }

    /**
     * Checks to see if the police will collide with any other police office on any of its next possible moves.
     * Author: Adam & Matt
     * @param police - array of actors
     * @param policeNum - the current actors space within the array.
     * @return
     * Assumption that only one Actor within radius of another Actor
     * The code checks the other actors to see if any other actors are nearby, if there is anyone they will attempt to avoid them.
     */

    public void collPolice(ArrayList<Police> police, int policeNum, boolean[] collisionArr)
    {
        int currx = getCurrx();
        int curry = getCurry();
        int nearx = 0;
        int neary = 0;

        for (int i = 0; i < police.size(); i++)
        {
            if(i != policeNum){
            nearx = police.get(i).getCurrx();
            neary = police.get(i).getCurry();
            // we need to swap the currs with the nears
                if (nearx >= (currx-6) && nearx <= (currx+6)) {
                    if (neary >= (curry-6) && neary <= (curry+6)) {
                        Actor curr = police.get(policeNum);
                        Actor near = police.get(i);
                        resolveCollision(curr, near, collisionArr);
                        break;
                    }
                }
            }
        }
    }

    /**
     * Checks to see if the police officer will collide with a civilian on its next turn
     * Author: Adam & Matt
     * @param civilian - the ArrayList containing all of the different civilian actors.
     * @param police - the ArrayList containing all of the different police actors.
     * @param policeNum - references the field within the police ArrayList which relates to this Police object. Move the police
     * @param collisionArr - - array containing all the directions which the actor will collide with another actor.
     * @return
     */
    public void collCivi(ArrayList<Civilian> civilian, ArrayList<Police> police, int policeNum, boolean[] collisionArr)
    {
        int currx = getCurrx();
        int curry = getCurry();
        int nearx = 0;
        int neary = 0;

        for (int j = 0; j <civilian.size(); j++)
        {
            if (j != policeNum) {
                nearx = civilian.get(j).getCurrx();
                neary = civilian.get(j).getCurry();
                // we need to swap the currs with the nears
                if (nearx >= (currx-6) && nearx <= (currx+6)) {
                    if (neary >= (curry-6) && neary <= (curry+6)) {
                        Actor curr = police.get(policeNum);
                        Actor near = civilian.get(j);
                        resolveCollision(curr, near, collisionArr);
                        break;
                    }
                }
            }
        }
    }

    /**
     * Author: Adam & Matt
     * Fills the collision array with "TRUE" in the directions where the Police cannot move without causing a collision.
     * so if the Police cannot move up, it will make top left, up and top right references = true.
     * @param curr - current actor
     * @param near - actor which the current actor is to collide with.
     * @param collisionArr - array containing all the directions that the actor will collide with another actor.
     */
    public void resolveCollision(Actor curr, Actor near, boolean[] collisionArr){

        int currx = curr.getCurrx();
        int curry = curr.getCurry();
        int nearx = near.getCurrx();
        int neary = near.getCurry();

        if(currx == nearx){
            if(curry > neary){
                //above
                collisionArr[1] = true;
                collisionArr[2] = true;
                collisionArr[3] = true;
            }
            else{
                //below
                collisionArr[6] = true;
                collisionArr[7] = true;
                collisionArr[8] = true;
            }
        }
        else if(curry == neary){
            if(currx > nearx){
                //left
                collisionArr[1] = true;
                collisionArr[4] = true;
                collisionArr[7] = true;
            }
            else{
                //right;
                collisionArr[2] = true;
                collisionArr[5] = true;
                collisionArr[8] = true;
            }
        }
        //tl bl tr br
        else if(currx < nearx){
            if(curry > neary){
                //top right
                collisionArr[2] = true;
                collisionArr[3] = true;
                collisionArr[5] = true;
            }
            else{
                //bottright
                collisionArr[5] = true;
                collisionArr[7] = true;
                collisionArr[8] = true;
            }
        }
        else if(currx > nearx){
            if(curry > neary){
                //top left
                collisionArr[2] = true;
                collisionArr[1] = true;
                collisionArr[4] = true;
            }
            else{
                //bottom left
                collisionArr[6] = true;
                collisionArr[7] = true;
                collisionArr[4] = true;
            }
        }

    }

    /**
     * Compares the direction that the Rioter would like to travel against the collision away. If this direction is equal to false then it will move in that direction. If it
     * equals true then it will randomly select a direction that they are able to move into without a collision.
     * Author: Adam
     * @param collisionArr - array containing all the directions that the actor will collide with another actor.
     * @param nextDirection - The direction the actor would like to travel in.
     */
    public void collisionDecision(boolean[] collisionArr, int nextDirection){
        if(nextDirection==0){
            nextDirection = 1;
        }
        boolean allTrue = true;
        // while the "next" field equals a move option which is not in the "collisionArr" array then pick a new number.
        for(int i = 1; i < collisionArr.length; i++){
            if( collisionArr[i] == false){
                allTrue = false;
                break;
            }
        }
        if (allTrue == false){

            while (collisionArr[nextDirection] == true ){
                nextDirection = 1 + (rand.nextInt(8));
            }
            //move the actor depending on the "next" field.
            switch (nextDirection){
                case 0: break;
                case 1: moveTopLeft(); break;
                case 2: moveUp(); break;
                case 3: moveTopRight(); break;
                case 4: moveLeft(); break;
                case 5: moveRight(); break;
                case 6: moveBotLeft(); break;
                case 7: moveDown(); break;
                case 8: moveBotRight(); break;
                default: break;
            }
        }
        else{
            //Don't move
        }
    }

    public String getType(){
        return type;
    }

    /**
     * Author: Matt
     * @param rioter
     * @param police
     * @param a
     * @return true if police is getting attacked
     */
    public boolean attacked(ArrayList<Rioter> rioter, ArrayList<Police> police, int a)
    {
        attack = rioter.get(a).attack(rioter, police, a);

        if (attack)
        {
            beingAttacked();
        }
        return attack;
    }

    /**
     * Author: Matt
     * Reduce police officers health if they have been attacked
     */
    public void beingAttacked()
    {
        if (attack && maxHealth >= 0)
        {
            maxHealth=-5;
        }
    }

    /**
     * Author: Matt
     * @return true if police is getting attacked
     */
    public boolean getAttack()
    {
        return attack;
    }

    /**
     * Author: Matt
     * @return true if police is fleeing
     */
    public boolean getFlee()
    {
        return flee;
    }

    /**
     * Return strength of the police officer.
     * @Author Ben.
     *
     * @return strength The strength of this officer.
     */
    public int getStrength(){ return strength; }
}
