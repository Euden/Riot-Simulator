import java.awt.*;
import javax.swing.*;
import java.util.ArrayList;

/**
 * Runs the rest of the program, moves the actors within the simulation and initialises colours.
 * Authors: Rahul, Matt, Ben
 */
public class Screen extends JPanel implements Runnable {

    // Size Variables
    public static final int WIDTH = 700;
    public static final int HEIGHT = 700;
    public static final String NAME = "Simulator";

    //Initialise variables
    public int currentAnger;
    public int currentFear;
    public int totalArrested;
    public int civiTotalFleeing;
    public int riotTotalFleeing;
    public int policeTotalFleeing;

    //Actors arraylists
    ArrayList<Police> police;
    ArrayList<Rioter> rioter;
    ArrayList<Civilian> civilian;
    ArrayList<Building> b;

    // Core Thread
    private boolean running;
    private int FPS = 30;
    private long targetTime = 1000/FPS;
    public boolean debug;
    // Image Processing
    private Graphics g;

    /**
     * Constructor: initalise fields and screen sizes
     * Author: Ben
     * @param police The police officer arraylist.
     * @param rioter The rioter array list.
     * @param b The list of buildins.
     * @param civilian The list of civilians.
     */
    public Screen(ArrayList<Police> police,ArrayList<Rioter> rioter, ArrayList<Building> b, ArrayList<Civilian> civilian)
    {
        super();
        this.police = police;
        this.rioter = rioter;
        this.civilian = civilian;
        this.b = b;
        setPreferredSize(new Dimension(WIDTH,HEIGHT));
        setMinimumSize(new Dimension(WIDTH,HEIGHT));
        setMaximumSize(new Dimension(WIDTH,HEIGHT));
        setBackground(Color.WHITE);
        setDoubleBuffered(true);
        setIgnoreRepaint(true);
    }

    /**
     * Run the core thread and update the program
     * Author: Ben, Rahul, Matt
     */
    @Override
    public void run() {
        final Runnable drawing = new Runnable() {
            public void run() {
                repaint();
            }
        };

        Thread painter = new Thread() {
            public void run() {
                try {
                    SwingUtilities.invokeAndWait(drawing);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
                running = true;
                while(running){
                    updatePol();
                    updateRioters();
                    updateCivilians();
                    calculateAnger(rioter);
                    calculateFear(rioter);
                    totalArrested = totalArrested();
                    civiTotalFleeing = civiTotalFleeing();
                    riotTotalFleeing = riotTotalFleeing();

                    if (totalArrested() == rioter.size() || riotTotalFleeing() == rioter.size() || totalArrested() + riotTotalFleeing() >= rioter.size())
                    {
                        endState1();
                    }

                    if (policeTotalFleeing() == police.size() && police.size() != 0)
                    {
                        endState2();
                    }

                    firePropertyChange("GUI", false, true);
                    try{
                        Thread.sleep(targetTime);
                    }
                    catch (InterruptedException e){
                    }
                    repaint();
                }
            }
        };
        painter.start();
    }

    /**
     * Counts the number of rioters arrested
     * Author: Rahul
     */
    public int totalArrested(){
        int totalArr = 0;
        //For every rioter and if they're arrested, increment the number
        for (Rioter r : rioter){
            if (r.isArrested()){
                totalArr++;
            }
        }
        rioterFlee(rioter, totalArr); //Author: Matt
        return totalArr;
    }

    /**
     * Counts the number of rioters currently fleeing
     * @param rioters
     * @param totalArr
     */
    public void rioterFlee(ArrayList<Rioter> rioters, int totalArr)
    {
        //Creates a percentage value for the number fleeing
        float arrestPercent = (totalArr * 100.0f) / rioters.size();

        //If the percentage is greater than 85% and if rioters are not arrested, they will flee
        if (arrestPercent > 85)
        {
            for (Rioter r : rioter)
            {
                if (r.isArrested() == false)
                {
                    r.flee();
                }
            }
        }
    }

    /**
     * Author: Matt
     * @return The number of civilians that are fleeing at any given time
     */
    public int civiTotalFleeing(){
        int totalFled = 0;
        //For every civilian, get boolean value if they're fleeing, if true increment
        for (Civilian c : civilian){
            if (c.getFlee()) {
                totalFled++;
            }
            if (c.getFled()) {
                totalFled--;
            }
        }
        return totalFled;
    }

    /**
     * Author: Matt
     * @return The number of rioters that are fleeing at any given time
     */
    public int riotTotalFleeing(){
        int totalFled = 0;
        //For every rioter, get boolean value if they're fleeing, if true increment
        for (Rioter r : rioter){
            if (r.getFlee()) {
                totalFled++;
            }
            if (r.getFled()) {
                totalFled--;
            }
        }
        return totalFled;
    }

    /**
     * Author: Matt
     * @return The number of police that are fleeing at any given time
     */
    public int policeTotalFleeing(){
        int totalFled = 0;
        for (Police p : police){
            if (p.getFlee()) {
                totalFled++;
            }
            if (p.getFled())
            {
                totalFled--;
            }
        }
        return totalFled;
    }

    public void endState1()
    {
        JOptionPane.showMessageDialog(null, "All rioters have been arrested or are fleeing.", "Simulation End", JOptionPane.PLAIN_MESSAGE);
        System.exit(0);
    }

    public void endState2()
    {
        JOptionPane.showMessageDialog(null, "Viva la Resistance!", "Simulation End", JOptionPane.PLAIN_MESSAGE);
        System.exit(0);
    }

    /**
     * Author: Ben
     * Updates the police location and moves them
     */
    private void updatePol ()
    {
        for(int i = 0; i < police.size(); i++)
        {
            police.get(i).move(police, rioter, civilian, i);
        }
    }

    /**
     * Author: Rahul
     * @param rioter - Takes in rioter array list for iteration
     * @return - Returns average value of all rioters on screen
     */
    public int calculateAnger(ArrayList<Rioter> rioter){

        int totalAnger = 0;
        int avg = 0;

        // Calculate overall anger
        for(int i = 0; i < rioter.size(); i++)
        {
            int anger = rioter.get(i).getAnger();
            totalAnger += anger;
        }
        // Calculate average
        avg = totalAnger / rioter.size();

        if (rioter.size() == 0) {
            currentAnger = 0;
        } else {
            currentAnger = totalAnger / rioter.size();
        }
        return currentAnger;
    }

    /**
     * Author: Rahul
     * @param rioter - Takes in rioter array list for iteration
     * @return - Returns average value of all rioters on screen
     */
    public int calculateFear(ArrayList<Rioter> rioter){

        int totalFear = 0;
        int avg = 0;

        // Calculate overall anger
        for(int i = 0; i < rioter.size(); i++)
        {
            int fear = rioter.get(i).getFear();
            totalFear += fear;
        }
        // Calculate average
        currentFear = totalFear / rioter.size();

        if (rioter.size() == 0) {
            currentFear = 0;
        } else {
            currentFear = totalFear / rioter.size();
        }
        return currentFear;
    }

    /**
     * Author: Ben, Rahul, Adam
     * Update and move the rioters
     */
    private void updateRioters (){
        for(int i = 0; i < rioter.size(); i++)
        {
            //Author: Adam
            if(i >= rioter.size()){
                break;
            }
            //End Author: Adam
            rioter.get(i).move(police, rioter, civilian, i);
            contagion(rioter, i); //Author: Rahul
            fearContagion(rioter, i); //Author: Rahul
        }
    }

    /**
     * Author: Matt
     * Update and move the civilians
     */
    private void updateCivilians () {
        for (int i = 0; i < civilian.size(); i++)
        {
            civilian.get(i).move(police, rioter, civilian, b, i);
        }
    }

    /**
     * Author: Rahul, Matt
     * Determine the rioters anger values based on those surrounding it
     * @param riots - Takes in rioter array list
     * @param z - Iterator to check surrounding rioter(s)
     */
    public void contagion(ArrayList<Rioter> riots, int z){

        int currentX = riots.get(z).getCurrx();
        int currentY = riots.get(z).getCurry();
        int nearAnger = riots.get(z).getAnger();
        boolean arrested = riots.get(z).isArrested();
        int maxanger = 100;

        int nearX = 0;
        int nearY = 0;
        int anger = 0;

        for (int i = 0; i < riots.size(); i++){
            if (i != z){
                nearX = riots.get(i).getCurrx();
                nearY = riots.get(i).getCurry();

                if(nearX >= (currentX - 20) && nearX <= (currentX + 20)){
                    if (nearY >= (currentY - 20) && nearY <= (currentY + 20)){
                        anger = riots.get(i).getAnger(); //anger for all agents are received
                        if(nearAnger < anger){
                            //Author: Matt
                            if (nearAnger <= maxanger) {
                               nearAnger ++;
                            }
                            //End Author: Matt

                            int nearfear = riots.get(i).getFear();
                            int maxfear = 100;

                            //Author: Matt
                            if (nearfear >= 0) {
                                nearfear -= 20;
                            }
                            //End Author: Matt

                            if (nearAnger > nearfear) {
                                angerContagionColour(riots, nearAnger, maxanger, z);
                            } else {
                                fearContagionColour(riots, nearAnger, maxanger, z);
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Author: Rahul, Matt
     * Determine the rioters fear based on those surrounding it
     * @param rioter - Tskes in rioter array list
     * @param z - Iterator to check surrounding rioters
     */
    public void fearContagion(ArrayList<Rioter> rioter, int z){
        int currentX = rioter.get(z).getCurrx();
        int currentY = rioter.get(z).getCurry();
        int nearfear = rioter.get(z).getFear();

        int maxfear = 100;
        int nearX;
        int nearY;
        int fear;

        for (int i = 0; i < rioter.size(); i++){
            if (i != z){
                nearX = rioter.get(i).getCurrx();
                nearY = rioter.get(i).getCurry();

                if(nearX >= (currentX - 20) && nearX <= (currentX + 20)){
                    if (nearY >= (currentY - 20) && nearY <= (currentY + 20)){
                        fear = rioter.get(i).getFear(); //anger for all agents are received
                        if(nearfear < fear){
                            //Author: Matt
                            if (nearfear <= maxfear) {
                                nearfear ++;
                            }
                            //End Author: Matt

                            int nearAnger = rioter.get(i).getAnger();
                            int maxanger = 100;

                            //Author: Matt
                            if (nearAnger >= 0) {
                                nearAnger -=20;
                            }
                            //End Author: Matt

                            //If their fear is greater than their anger, set their colour as fearful
                            if (nearfear > nearAnger) {
                                fearContagionColour(rioter, nearAnger, maxanger, z);
                            } else {
                                //If their anger is greater than their fear, set their colour as angry
                                angerContagionColour(rioter, nearAnger, maxanger, z);
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Author: Rahul
     * @param rioter - Takes in rioter array list
     * @param nearAnger - Takes rioter's anger value to check which color range it fits in
     * @param maxanger - Global variable to take in to check if rioter has max anger value
     * @param a - Parameter to color all rioters
     */
    public void angerContagionColour(ArrayList<Rioter> rioter, int nearAnger, int maxanger, int a)
    {
        boolean arrested = rioter.get(a).isArrested();

        Color c = null;

        //Initialise the colours
        Color def = new Color(255,180,180);
        Color anger1 = new Color(255,160,160);
        Color anger2 = new Color(255,140,140);
        Color anger3 = new Color(255,120,120);
        Color anger4 = new Color(255,100,100);
        Color anger5 = new Color(255,80,80);
        Color anger6 = new Color(255,60,60);
        Color anger7 = new Color(255,40,40);
        Color anger8 = new Color(255,20,20);
        Color max = new Color(255,0,0);
        Color arrestCol = new Color(0, 255, 0);

        //If they're arrested, set colour to green
        if (arrested){
            c = arrestCol;
            rioter.get(a).setColor(c);
        }
        //If they're not arrested, set colour based on their anger value
        else if (nearAnger >= 0 && nearAnger <= 9){
            c = def;
            rioter.get(a).setColor(c);
        }
        else if(nearAnger >= 10 && nearAnger <= 19){
            c = anger1;
            rioter.get(a).setColor(c);
        }
        else if(nearAnger >= 20 && nearAnger <= 29){
            c = anger2;
            rioter.get(a).setColor(c);
        }
        else if(nearAnger >= 30 && nearAnger <= 39){
            c = anger3;
            rioter.get(a).setColor(c);
        }
        else if(nearAnger >= 40 && nearAnger <= 49){
            c = anger4;
            rioter.get(a).setColor(c);
        }
        else if(nearAnger >= 50 && nearAnger <= 59){
            c = anger5;
            rioter.get(a).setColor(c);
        }
        else if (nearAnger >= 60 && nearAnger <= 69){
            c = anger6;
            rioter.get(a).setColor(c);
        }
        else if(nearAnger >= 70 && nearAnger <= 79){
            c = anger7;
            rioter.get(a).setColor(c);
        }
        else if(nearAnger >= 80 && nearAnger <= 89){
            c = anger8;
            rioter.get(a).setColor(c);
        }
        else if(nearAnger >= 90 && nearAnger <= maxanger){
            c = max;
            rioter.get(a).setColor(c);
        }
        rioter.get(a).setAnger(nearAnger);
    }

    /**
     * Author: Rahul
     * @param rioter - Takes in rioter array list
     * @param nearfear - Tskes in rioter fear values
     * @param maxfear - Takes global max fear value to see if rioter has max fear
     * @param a - Parameter to color all fear values, if scared
     */
    public void fearContagionColour(ArrayList<Rioter> rioter, int nearfear, int maxfear, int a)
    {
        boolean arrested = rioter.get(a).isArrested();

        Color c = null;

        //Initialise the colours
        Color defFear = new Color(224,176,255);
        Color fear1 = new Color(221,160,221);;
        Color fear2 = new Color(223,115,225);
        Color fear3 = new Color (203,100,205);
        Color fear4 = new Color (180,92,240);
        Color fear5 = new Color (152,66,227);
        Color fear6 = new Color (101,45,180);
        Color fear7 = new Color(75,48,141);
        Color fear8 = new Color(75,0,130);
        Color maxFear = new Color(78,0,65);

        Color arrestCol = new Color(0, 255, 0);

        //If they rioter is arrested, set colour to green
        if (arrested){
            c = arrestCol;
            rioter.get(a).setColor(c);
        }
        //If they're not arrested, set colour to purple depending on fear
        else if (nearfear >= 0 && nearfear <= 9){
            c = defFear;
            rioter.get(a).setColor(c);
        }
        else if(nearfear >= 10 && nearfear <= 19){
            c = fear1;
            rioter.get(a).setColor(c);
        }
        else if(nearfear >= 20 && nearfear <= 29){
            c = fear2;
            rioter.get(a).setColor(c);
        }
        else if(nearfear >= 30 && nearfear <= 39){
            c = fear3;
            rioter.get(a).setColor(c);
        }
        else if(nearfear >= 40 && nearfear <= 49){
            c = fear4;
            rioter.get(a).setColor(c);
        }
        else if(nearfear >= 50 && nearfear <= 59){
            c = fear5;
            rioter.get(a).setColor(c);
        }
        else if (nearfear >= 60 && nearfear <= 69){
            c = fear6;
            rioter.get(a).setColor(c);
        }
        else if(nearfear >= 70 && nearfear <= 79){
            c = fear7;
            rioter.get(a).setColor(c);
        }
        else if(nearfear >= 80 && nearfear <= 89){
            c = fear8;
            rioter.get(a).setColor(c);
        }
        else if(nearfear >= 90 && nearfear <= maxfear){
            c = maxFear;
            rioter.get(a).setColor(c);
        }
        rioter.get(a).setFear(nearfear);
    }

    /**
     * Author: Ben, Rahul
     * @param g
     */
    protected void paintComponent(Graphics g)
    {
        //set all colours for rioters depending on anger

        //Create default colours
        Color def = new Color(255,180,180);
        super.paintComponent(g);
        g.setColor(Color.BLACK);

        Color co = null;
        g.setColor(def);

        //Set the default colour for rioters with debug
        synchronized (Simulator.rioterLock){ //Author: Rahul
            for (Rioter r : rioter){
                co = r.getColor();
                g.setColor(co);
                r.draw(g, debug);
            }
        }

        //Set the default colour for police with debug
        g.setColor(Color.BLUE);
        synchronized (Simulator.policeLock){ //Author: Rahul
            for(Police p : police)
            {
                p.draw(g, debug);
            }
        }

        //Set the default colour for civilian with debug
        g.setColor(Color.black);
        synchronized (Simulator.civilianLock){ //Author: Rahul
            for (Civilian c : civilian)
            {
                c.draw(g, debug);
            }
        }

        //Set building debug
        for (Building a : b) {
            a.draw(g, debug);
        }

    }
}